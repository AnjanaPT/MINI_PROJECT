from django.apps import AppConfig


class AppmeConfig(AppConfig):
    name = 'appme'
