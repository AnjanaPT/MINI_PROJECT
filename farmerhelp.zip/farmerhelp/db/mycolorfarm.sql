-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 05, 2022 at 11:29 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mycolorfarm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_farmer_payment`
--

CREATE TABLE IF NOT EXISTS `admin_farmer_payment` (
  `paymentid` int(40) NOT NULL AUTO_INCREMENT,
  `farmerid` bigint(100) NOT NULL,
  `accountnumber` bigint(50) NOT NULL,
  `bankname` varchar(60) NOT NULL,
  `ifsccode` varchar(50) NOT NULL,
  `amount` bigint(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `admin_farmer_payment`
--


-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `categoryid` int(50) NOT NULL AUTO_INCREMENT,
  `Categoryname` varchar(100) NOT NULL,
  PRIMARY KEY (`categoryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryid`, `Categoryname`) VALUES
(1, 'vegetable'),
(2, 'chicken'),
(4, 'Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `doubt`
--

CREATE TABLE IF NOT EXISTS `doubt` (
  `doubtid` int(100) NOT NULL AUTO_INCREMENT,
  `Productname` varchar(100) NOT NULL,
  `doubt` varchar(500) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`doubtid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `doubt`
--

INSERT INTO `doubt` (`doubtid`, `Productname`, `doubt`, `dates`, `email`) VALUES
(1, 'brinjal', 'How to avoid insects on the brinjal', '2022-02-27', 'praveena@gmail.com'),
(2, 'Cardamom', 'Is it harmful to apply ddt to cardamom every month?', '2022-03-03', 'febi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `doubtreplay`
--

CREATE TABLE IF NOT EXISTS `doubtreplay` (
  `replayid` int(100) NOT NULL AUTO_INCREMENT,
  `Productname` varchar(100) NOT NULL,
  `dts` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `doubt` varchar(500) NOT NULL,
  `replay` varchar(500) NOT NULL,
  `dates` varchar(100) NOT NULL,
  PRIMARY KEY (`replayid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `doubtreplay`
--

INSERT INTO `doubtreplay` (`replayid`, `Productname`, `dts`, `email`, `doubt`, `replay`, `dates`) VALUES
(1, 'brinjal', '2019-12-29', 'hhhh', 'How to avoid insects on the brinjal', 'Add Replay', '2022-03-04'),
(2, 'Cardamom', '2022-03-03', 'febi@gmail.com', 'Is it harmful to apply to cardamom every month?', 'It will be okay to some extend but high usage can be harmful', '2022-03-04');

-- --------------------------------------------------------

--
-- Table structure for table `equipmentcart`
--

CREATE TABLE IF NOT EXISTS `equipmentcart` (
  `cartno` int(100) NOT NULL AUTO_INCREMENT,
  `productid` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`cartno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `equipmentcart`
--

INSERT INTO `equipmentcart` (`cartno`, `productid`, `dates`, `email`, `status`) VALUES
(1, '1', '2022-03-04', 'febi@gmail.com', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `equipmentpayment`
--

CREATE TABLE IF NOT EXISTS `equipmentpayment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `cardnumber` varchar(100) NOT NULL,
  `cvv` varchar(500) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `ifsc` varchar(50) NOT NULL,
  `amount` bigint(50) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `equipmentpayment`
--


-- --------------------------------------------------------

--
-- Table structure for table `exporters`
--

CREATE TABLE IF NOT EXISTS `exporters` (
  `Exp_regnumber` int(50) NOT NULL AUTO_INCREMENT,
  `ExpotrersName` varchar(50) NOT NULL,
  `RegistraionCode` varchar(100) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `State` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `PhoneNumber` bigint(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `AccountNumber` varchar(100) NOT NULL,
  `BankName` varchar(100) NOT NULL,
  `IFSC` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`Exp_regnumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `exporters`
--

INSERT INTO `exporters` (`Exp_regnumber`, `ExpotrersName`, `RegistraionCode`, `Country`, `State`, `District`, `PhoneNumber`, `dates`, `file`, `email`, `password`, `AccountNumber`, `BankName`, `IFSC`, `status`) VALUES
(12, 'Elizabeth', 'elizabeth@gmail.com', 'India', 'Kerala', 'Idukki', 7902698556, '2022-03-02T15:20', '/media/aadhaar1_Ft7X9Ls.jpg', 'elizabeth@gmail.com', 'elizabeth@12', '19048548901', 'SBI', 'SBIN0007569', 'Approved'),
(13, 'Emi', 'emi@gmail.com', 'India', 'Kerala', 'Ernakulam', 7909685234, '2022-03-02T15:23', '/media/aadhaar1_JITO7xn.jpg', 'emi@gmail.com', 'emi@12', '22345678901', 'UBI', 'UBIN0007569', 'pending'),
(14, 'anjana', 'apt', 'India', 'Kerala', 'Malappuram', 1234567867, '2022-03-04T10:10', '/media/aadhaar1_GQeSDln.jpg', 'anjana@gmail.com', 'anjana@12', '12345678909', 'SBI', 'SBIN0007568', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `exportersorder`
--

CREATE TABLE IF NOT EXISTS `exportersorder` (
  `orderid` int(100) NOT NULL AUTO_INCREMENT,
  `Productname` varchar(100) NOT NULL,
  `Quantity` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `cardnumber` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `ifsc` varchar(100) NOT NULL,
  `amount` bigint(100) NOT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `exportersorder`
--

INSERT INTO `exportersorder` (`orderid`, `Productname`, `Quantity`, `email`, `dates`, `status`, `cardnumber`, `cvv`, `accountnumber`, `ifsc`, `amount`) VALUES
(3, 'Banana', 10, 'elizabeth@gmail.com', '2022-03-03', 'Approved', '1234432112344321', '565', '19048548901', 'SBIN0007569', 20),
(4, 'Banana', 10, 'anjana@gmail.com', '2022-03-04', 'pending', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `farmentcapitalrequest`
--

CREATE TABLE IF NOT EXISTS `farmentcapitalrequest` (
  `investid` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `amount` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  PRIMARY KEY (`investid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `farmentcapitalrequest`
--

INSERT INTO `farmentcapitalrequest` (`investid`, `name`, `mobile`, `amount`, `email`, `dates`) VALUES
(1, 'Febi', 7558810669, 20000, 'febi@gmail.com', '2022-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `farmerpayment`
--

CREATE TABLE IF NOT EXISTS `farmerpayment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `farmerid` bigint(100) NOT NULL,
  `amount` bigint(100) NOT NULL,
  `dts` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `farmerpayment`
--


-- --------------------------------------------------------

--
-- Table structure for table `farmerreg`
--

CREATE TABLE IF NOT EXISTS `farmerreg` (
  `farmerid` int(100) NOT NULL AUTO_INCREMENT,
  `FarmersName` varchar(50) NOT NULL,
  `HouseName` varchar(100) NOT NULL,
  `State` varchar(100) NOT NULL,
  `District` varchar(100) NOT NULL,
  `panchayath` varchar(50) NOT NULL,
  `Postoffice` varchar(50) NOT NULL,
  `PostalZipCode` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` bigint(100) NOT NULL,
  `proof` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `AccountNumber` bigint(100) NOT NULL,
  `NameoftheBank` varchar(100) NOT NULL,
  `IFSC` varchar(100) NOT NULL,
  PRIMARY KEY (`farmerid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `farmerreg`
--

INSERT INTO `farmerreg` (`farmerid`, `FarmersName`, `HouseName`, `State`, `District`, `panchayath`, `Postoffice`, `PostalZipCode`, `email`, `phonenumber`, `proof`, `password`, `status`, `AccountNumber`, `NameoftheBank`, `IFSC`) VALUES
(30, 'Febi', 'Vazhattu', 'Kerala', 'Thiruvananthapuram', 'Trivandrum', 'Trivandrum', '676619', 'febi@gmail.com', 7558810669, '/media/aadhaar1.jpg', 'febi@12', 'Approved', 12348978999, 'SBI', 'SBIN0008969'),
(31, 'Fida', 'Kollumpurath', 'Kerala', 'Kollam', 'Kollam', 'Kollam', '685619', 'fida@gmail.com', 7909685678, '/media/aadhaar1_D2ceIhA.jpg', 'fida@12', 'Pending', 12323628901, 'SBI', 'SBIN0007569'),
(32, 'Febin', 'Vazhattu', 'Kerala', 'Palakkadu', 'Palakkad', 'Palakkadu', '685345', 'febin@gmail.com', 7552210669, '/media/aadhaar1_A4maGXq.jpg', 'febin@12', 'Approved', 12345678909, 'UBI', 'UBIN0007569');

-- --------------------------------------------------------

--
-- Table structure for table `farmingtechnique`
--

CREATE TABLE IF NOT EXISTS `farmingtechnique` (
  `followupid` int(100) NOT NULL AUTO_INCREMENT,
  `itemname` varchar(100) NOT NULL,
  `techniquename` varchar(100) NOT NULL,
  `followups` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`followupid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `farmingtechnique`
--

INSERT INTO `farmingtechnique` (`followupid`, `itemname`, `techniquename`, `followups`, `email`) VALUES
(1, 'Tapioca', 'Organic', 'Organic fertilizers are used.no chemical is added.', 'febin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `feedid` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dates` varchar(50) NOT NULL,
  `feedback` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedid`, `name`, `mobile`, `email`, `dates`, `feedback`) VALUES
(0, 'Praveena', 7689456723, 'praveena@gmail.com', '2022-03-03', 'Moderate');

-- --------------------------------------------------------

--
-- Table structure for table `investors`
--

CREATE TABLE IF NOT EXISTS `investors` (
  `Specializedid` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `MobileNumber` bigint(50) NOT NULL,
  `OfficeName` varchar(100) NOT NULL,
  `OfficeContact` bigint(100) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Specialized` varchar(100) NOT NULL,
  `Message` varchar(500) NOT NULL,
  PRIMARY KEY (`Specializedid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `investors`
--

INSERT INTO `investors` (`Specializedid`, `Name`, `Email`, `MobileNumber`, `OfficeName`, `OfficeContact`, `Designation`, `Specialized`, `Message`) VALUES
(5, 'Indu', 'indu@gmail.com', 7909685679, 'indu financials', 7890567858, 'MD', 'None', 'Entrepreneur');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`, `status`) VALUES
('admin@gmail.com', 'admin', 'admin', 'Approved'),
('febi@gmail.com', 'febi@12', 'farmer', 'Approved'),
('fida@gmail.com', 'fida@12', 'farmer', 'pending'),
('praveena@gmail.com', 'praveena@12', 'Public', 'Approved'),
('pathma@gmail.com', 'pathma@12', 'Public', 'Approved'),
('elizabeth@gmail.com', 'elizabeth@12', 'Exporters', 'Approved'),
('emi@gmail.com', 'emi@12', 'Exporters', 'pending'),
('saran@gmail.com', 'saran@12', 'suppliers', 'Approved'),
('sarang@gmail.com', '7902698558', 'Specialist', 'Approved'),
('febin@gmail.com', 'febin@12', 'farmer', 'Approved'),
('anjana@gmail.com', 'anjana@12', 'Exporters', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `pesticidecart`
--

CREATE TABLE IF NOT EXISTS `pesticidecart` (
  `cartno` int(100) NOT NULL AUTO_INCREMENT,
  `productid` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`cartno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pesticidecart`
--


-- --------------------------------------------------------

--
-- Table structure for table `pesticidepayment`
--

CREATE TABLE IF NOT EXISTS `pesticidepayment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `cardnumber` varchar(100) NOT NULL,
  `cvv` varchar(500) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `ifsc` varchar(50) NOT NULL,
  `amount` bigint(50) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `pesticidepayment`
--


-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `productid` int(100) NOT NULL AUTO_INCREMENT,
  `cat` varchar(100) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `rate` bigint(100) NOT NULL,
  `quantity` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productid`, `cat`, `productname`, `file`, `unit`, `rate`, `quantity`, `email`) VALUES
(1, 'vegetable', 'bitterMelon', '/media/bitterMelon.png', 'kg', 20, 100, 'febin@gmail.com'),
(2, 'Fruits', 'Banana', '/media/bananaPlant.jpeg', 'kg', 25, 100, 'febi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `productcart`
--

CREATE TABLE IF NOT EXISTS `productcart` (
  `cartno` int(100) NOT NULL AUTO_INCREMENT,
  `productid` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`cartno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `productcart`
--

INSERT INTO `productcart` (`cartno`, `productid`, `dates`, `email`) VALUES
(2, '1', '2022-03-03', 'febi@gmail.com'),
(3, '1', '2022-03-04', 'febi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `productpayment`
--

CREATE TABLE IF NOT EXISTS `productpayment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `cardnumber` varchar(100) NOT NULL,
  `cvv` varchar(500) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `ifsc` varchar(50) NOT NULL,
  `amount` bigint(50) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `productpayment`
--


-- --------------------------------------------------------

--
-- Table structure for table `publicreg`
--

CREATE TABLE IF NOT EXISTS `publicreg` (
  `pubid` int(50) NOT NULL AUTO_INCREMENT,
  `yourname` varchar(50) NOT NULL,
  `phonenumber` bigint(100) NOT NULL,
  `Username` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`pubid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `publicreg`
--

INSERT INTO `publicreg` (`pubid`, `yourname`, `phonenumber`, `Username`, `Password`) VALUES
(7, 'Praveena', 7689456723, 'praveena@gmail.com', 'praveena@12'),
(8, 'Pathma', 8908795645, 'pathma@gmail.com', 'pathma@12');

-- --------------------------------------------------------

--
-- Table structure for table `seed`
--

CREATE TABLE IF NOT EXISTS `seed` (
  `seedid` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `file1` varchar(100) NOT NULL,
  `scientificname` varchar(100) NOT NULL,
  `verity` varchar(100) NOT NULL,
  `rate` varchar(100) NOT NULL,
  `quantity` bigint(100) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`seedid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `seed`
--

INSERT INTO `seed` (`seedid`, `Name`, `file1`, `scientificname`, `verity`, `rate`, `quantity`, `Description`, `unit`, `email`) VALUES
(1, 'BananaSeedlings', '/media/bananaSeedlings.jpg', 'Musa', '10', '100', 100, 'BananaPlant', 'kg', 'febin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `seedcart`
--

CREATE TABLE IF NOT EXISTS `seedcart` (
  `cartno` int(100) NOT NULL AUTO_INCREMENT,
  `seedid` varchar(100) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`cartno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `seedcart`
--


-- --------------------------------------------------------

--
-- Table structure for table `seedpayment`
--

CREATE TABLE IF NOT EXISTS `seedpayment` (
  `paymentid` int(100) NOT NULL AUTO_INCREMENT,
  `cardnumber` varchar(100) NOT NULL,
  `cvv` varchar(500) NOT NULL,
  `accountnumber` varchar(100) NOT NULL,
  `ifsc` varchar(50) NOT NULL,
  `amount` bigint(50) NOT NULL,
  `dates` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `seedpayment`
--


-- --------------------------------------------------------

--
-- Table structure for table `specialized`
--

CREATE TABLE IF NOT EXISTS `specialized` (
  `Specializedid` int(100) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `MobileNumber` bigint(50) NOT NULL,
  `OfficeName` varchar(100) NOT NULL,
  `OfficeContact` bigint(100) NOT NULL,
  `Designation` varchar(100) NOT NULL,
  `Specialized` varchar(100) NOT NULL,
  `Message` varchar(500) NOT NULL,
  PRIMARY KEY (`Specializedid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `specialized`
--

INSERT INTO `specialized` (`Specializedid`, `Name`, `Email`, `MobileNumber`, `OfficeName`, `OfficeContact`, `Designation`, `Specialized`, `Message`) VALUES
(6, 'Sarang', 'sarang@gmail.com', 7902698558, 'ABC', 7890567856, 'Trainer', 'Bittermelon Cultivation', 'Authorized Tarinee');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `sup_regnumber` int(50) NOT NULL AUTO_INCREMENT,
  `suppliersName` varchar(50) NOT NULL,
  `RegistraionCode` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `PhoneNumber` bigint(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `AccountNumber` varchar(100) NOT NULL,
  `BankName` varchar(100) NOT NULL,
  `IFSC` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`sup_regnumber`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`sup_regnumber`, `suppliersName`, `RegistraionCode`, `category`, `District`, `PhoneNumber`, `file`, `email`, `password`, `AccountNumber`, `BankName`, `IFSC`, `status`) VALUES
(12, 'Saran', 'saran@gmail.com', 'Pesticides', 'Malappuram', 7558810669, '/media/aadhaar1_JEb1aXy.jpg', 'saran@gmail.com', 'saran@12', '12895678912', 'UBI', 'UBIN0002269', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `suppliersproduct`
--

CREATE TABLE IF NOT EXISTS `suppliersproduct` (
  `productid` int(100) NOT NULL AUTO_INCREMENT,
  `suppliername` varchar(100) NOT NULL,
  `cat` varchar(100) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `rate` bigint(100) NOT NULL,
  `quantity` bigint(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `suppliersproduct`
--

INSERT INTO `suppliersproduct` (`productid`, `suppliername`, `cat`, `productname`, `file`, `unit`, `rate`, `quantity`, `email`) VALUES
(1, 'GrubHoe', 'Equipments', 'GrubHoe', '/media/grubHoe.jpg', 'count', 200, 10, 'saran@gmail.com'),
(2, 'DDT', 'Pesticides', 'DDT', '/media/ddt.jpg', 'ltr', 5000, 10, 'saran@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `testing`
--

CREATE TABLE IF NOT EXISTS `testing` (
  `testid` int(100) NOT NULL AUTO_INCREMENT,
  `Productname` varchar(100) NOT NULL,
  `testname` varchar(100) NOT NULL,
  `file1` varchar(100) NOT NULL,
  `result` varchar(100) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`testid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `testing`
--

